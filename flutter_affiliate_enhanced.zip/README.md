مشروع Flutter كامل (محسّن) جاهز للبناء.

طريقة الاستخدام السريعة:
1) ارفع هذا المجلد إلى GitHub (أو اضغط ZIP).
2) في CodeMagic اختر مشروعك وابدأ Build -> Android APK.
3) قبل البناء قد تحتاج تفعيل flutter_launcher_icons:
   - على CodeMagic، شغّل الأمر: flutter pub get && flutter pub run flutter_launcher_icons:main
   - أو قم بتضمين إعدادات الأيقونة يدوياً.

ملاحظات:
- الملف يحتوي placeholder لأيقونة (assets/images/ic_launcher.png)
- تم إضافة صلاحية INTERNET وملفات الـ Splash للأندرويد
