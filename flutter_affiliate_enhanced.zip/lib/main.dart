import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const AffiliateApp());

class Product {
  final String id;
  final String name;
  final String description;
  final String imageUrl;
  final String price;
  final String affiliateUrl;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.price,
    required this.affiliateUrl,
  });
}

final List<Product> availableProducts = [
  Product(
    id: 'p1',
    name: "ساعة ذكية فاخرة بشاشة AMOLED",
    description: "تتبع متقدم للياقة ومقاومة للماء.",
    imageUrl: "https://via.placeholder.com/600x400/FF5733/FFFFFF?text=Smart+Watch",
    price: "79.99\$",
    affiliateUrl: "https://ali.ski/link12345",
  ),
  Product(
    id: 'p2',
    name: "سماعات أذن لاسلكية",
    description: "إلغاء ضوضاء وبطارية طويلة.",
    imageUrl: "https://via.placeholder.com/600x400/1E90FF/FFFFFF?text=Earbuds",
    price: "45.50\$",
    affiliateUrl: "https://ali.ski/link67890",
  ),
  Product(
    id: 'p3',
    name: "جهاز عرض صغير",
    description: "حوّل غرفتك إلى سينما!",
    imageUrl: "https://via.placeholder.com/600x400/3CB371/FFFFFF?text=Mini+Projector",
    price: "120.00\$",
    affiliateUrl: "https://ali.ski/linkabcde",
  ),
  Product(
    id: 'p4',
    name: "حامل هاتف للسيارة",
    description: "تركيب سهل وآمن.",
    imageUrl: "https://via.placeholder.com/600x400/FFA500/FFFFFF?text=Car+Holder",
    price: "15.99\$",
    affiliateUrl: "https://ali.ski/linkfghij",
  ),
];

class AffiliateApp extends StatelessWidget {
  const AffiliateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيق تسويق الأفلييت',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFFE6000),
        scaffoldBackgroundColor: Colors.grey[50],
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFE6000),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      routes: {
        '/home': (_) => const HomeScreen(),
        '/contact': (_) => const ContactScreen(),
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState(){
    super.initState();
    Future.delayed(const Duration(milliseconds: 900), (){
      Navigator.of(context).pushReplacementNamed('/home');
    });
  }
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        color: const Color(0xFFFE6000),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.shopping_bag, size: 80, color: Colors.white),
              SizedBox(height: 12),
              Text('عروض علي إكسبرس', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold))
            ],
          ),
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final Function(String) onBuyPressed;

  const ProductCard({super.key, required this.product, required this.onBuyPressed});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => onBuyPressed(product.affiliateUrl),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 3,
              child: Image.network(
                product.imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const Center(child: Icon(Icons.image_not_supported, size: 40)),
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(product.price,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFFFE6000))),
                    SizedBox(
                      width: double.infinity,
                      height: 38,
                      child: ElevatedButton.icon(
                        onPressed: () => onBuyPressed(product.affiliateUrl),
                        icon: const Icon(Icons.shopping_cart, size: 18, color: Colors.black),
                        label: const Text("اذهب للشراء"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.black,
                          shape:
                              RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("أفضل عروض علي إكسبرس", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'اتصل بنا',
            icon: const Icon(Icons.contact_support),
            onPressed: () => Navigator.of(context).pushNamed('/contact'),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: GridView.builder(
          itemCount: availableProducts.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.65,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          itemBuilder: (context, index) {
            return ProductCard(
              product: availableProducts[index],
              onBuyPressed: _launchURL,
            );
          },
        ),
      ),
    );
  }
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('اتصل بنا')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('للتواصل أو الشكاوى:'),
            const SizedBox(height:10),
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('البريد الإلكتروني'),
              subtitle: const Text('support@example.com'),
              onTap: () async {
                final Uri mail = Uri.parse('mailto:support@example.com');
                if (await canLaunchUrl(mail)) await launchUrl(mail);
              },
            ),
            ListTile(
              leading: const Icon(Icons.link),
              title: const Text('صفحتنا'),
              subtitle: const Text('https://example.com'),
              onTap: () async {
                final Uri url = Uri.parse('https://example.com');
                if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
              },
            ),
          ],
        ),
      ),
    );
  }
}
